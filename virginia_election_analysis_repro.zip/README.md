# Virginia presidential election shifts, 2020–2024

An independent, reproducible analysis of official presidential returns for all
133 Virginia counties and independent cities. The accompanying article compares
the Democratic-minus-Republican margin in 2020 and 2024, identifies localities
with the largest changes, and documents a five-locality Northern Virginia group.

## Source data and retrieval

Downloaded on **October 28, 2026** from Virginia's official historical election
database. Both raw CSVs are included in this package, unmodified.

| Year | Official contest page | Exact CSV download endpoint | Local file |
| --- | --- | --- | --- |
| 2020 | https://historical.elections.virginia.gov/contest/144567 | https://va2.elstats3.civera.com/api/download_contest/144567_table.csv?split_party=false | `data/virginia_2020_president_official.csv` |
| 2024 | https://historical.elections.virginia.gov/contest/161256 | https://va2.elstats3.civera.com/api/download_contest/161256_table.csv?split_party=false | `data/virginia_2024_president_official.csv` |

The Virginia Department of Elections [certified the 2024 results on December 2,
2024](https://www.elections.virginia.gov/news-releases/archive/2024/2024-election-results-certified-1.html).
Its [2020 statewide audit](https://www.elections.virginia.gov/rla-results_nov-3-2020/)
reports the same 2020 presidential candidate vote totals as the historical file.

SHA-256 checksums of the downloaded CSV files:

```text
e3289bba8e9e0fce24cd06de2c4f9dbe091e14d3c3c710eee560aec145cae84a  data/virginia_2020_president_official.csv
f4e54c7fc691cc253ba2026cc37eb81945513600ad0fdef5fde50a3de50671c8  data/virginia_2024_president_official.csv
```

## Reproduce the analysis

Requires Python 3.9 or later. No third-party dependencies.

1. Extract the entire ZIP, preserving the `data/` folder.
2. Open a terminal in the extracted folder.
3. Run `python3 analyze.py` to regenerate `dist/analysis.json`,
   `dist/analysis.js` and `dist/virginia_locality_analysis.csv`.
4. Run `python3 verify.py` for an independent input-to-output audit.

The static website additionally uses `dist/index.html`, `dist/styles.css` and
`dist/app.js` from the site project. The ZIP focuses on the analysis and its
source files, not the website design.

## Definitions

- **Votes recorded for president:** Sum of votes for presidential candidates
  and presidential write-ins in the official contest results. It is **not**
  the number of ballots cast across the election, the registered-voter turnout
  rate, or the number of eligible voters who voted.
- **Democratic-minus-Republican (D–R) vote margin:** Democratic votes minus
  Republican votes. A negative value indicates a Republican lead.
- **D–R margin in percentage points:** `100 × (Democratic votes − Republican votes) / votes recorded for president`.
- **Shift toward Republicans:** The 2020 D–R percentage-point margin minus the
  2024 D–R percentage-point margin. A positive value means the D–R margin
  became more Republican. It is **not** Trump's change in vote share.
- **Reduction in raw D–R margin:** `(2020 Democratic votes − 2020 Republican
  votes) − (2024 Democratic votes − 2024 Republican votes)`. This is additive
  across localities; percentage-point shifts are not.
- **Five selected Northern Virginia localities:** Fairfax County, Arlington
  County, Alexandria City, Loudoun County and Prince William County. This is
  a transparent analytical grouping, not all of Northern Virginia or an
  official statistical region.

## Key checks from these particular source files

- 133 matching locality rows in each year; locality votes sum exactly to the
  state row for both candidates and for total presidential votes.
- 2020: Biden 2,413,568; Trump 1,962,430; 4,460,524 presidential votes.
- 2024: Harris 2,335,395; Trump 2,075,085; 4,505,941 presidential votes.
- Statewide Democratic vote margin: 451,138 (2020), 260,310 (2024), a
  decrease of 190,828 votes.
- D–R percentage-point margin declined in 120 of 133 localities.
- The selected five localities had 100,111 votes of the statewide D–R margin
  reduction (52.46%); they cast 27.93% of Virginia's 2024 presidential votes.
- Fairfax County's D–R vote margin declined by 46,999 votes.

## Interpretation limits

This compares two elections with different Democratic nominees and voters.
Locality-level results **cannot identify individual voters who changed their
preferences** or explain the relative roles of persuasion, population change,
new voters, abstention, third-party voting or other factors. The selected
five-locality comparison is descriptive and should not be interpreted as a
causal explanation or a statistical estimate. Results are conditional on the
Virginia official files downloaded on the date above; later revisions to the
source would require re-running and documenting the new version.

The analysis and article are a portfolio draft, not a New York Times product.
